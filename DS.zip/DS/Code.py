# list = [[],[]] or [0 for j in range(3) for i in range(5)]

try:
    num = 0
except ValueError:
    print("Error")
except:
    print("Error2")

file = open("text.txt",'w+')
file.write("Hello\n")
file.close()

import csv

file = open("text.txt",'r+')
r = csv.reader(file)
[print(row) for row in r]
file.close()

class Emp:
    e_count = 0
    def __init__(self, name, salary) -> None:
        self.name = name
        self.salary = salary
        Emp.e_count += 1

    def display(self):
        print("Name: ", self.name)

Emp1 = Emp("Max", 200)

import pandas as pd
df = pd.read_csv('table.csv', sep=';')
df.head()
df.describe()
df.shape
type(df[['Car']])
df[['Car', 'Engine']][5:15]
df.columns
df.dtypes
df.Cars.unique()
df.Cars.value_counts()
df[df.Engine == 'E35']
df[ (df.Hourse_power == 500) | (df.Hourse_power < 700) ]
df2 = pd.DataFrame({'ID': [1,2,3,4],'Name':['A','B','C','D']})
df2.append({'ID': 5,'Name': 'E'}, ignore_index =True)
df2['Wheel'] = [4,6,4,6,4]
df2.drop(0)
df2.drop(index=[1,4])
df2.drop(['Year','Model'], axis=1)
df2.info()
df2.fillna(0)
df2.cost.fillna(df2.cost.mean())
df2.buy.fillna(method='bfill')
df2.sell.fillna(method='ffill')
df2.interpolate(method='linear', limit_direction='forward')
df2.dropna(axis=1, thresh=3)
df2.drop_duplicates()
df2.reset_index(drop=True)

df2['Company'] = pd.to_numeric(df2['Company'], errors='coerce')
df2.used = df2.used.astype('category').cat.codes
df3 = pd.get_dummies(df2, columns=['Miles'])

from pandas.api.types import CategoricalDtype
cmp_name = ['Honda', 'Toyota', 'Kia']
ctype = CategoricalDtype(categories=cmp_name, ordered=True)
df2.manufacture = df2.manufacture.astype(ctype).cat.codes

row_concat = pd.concat([T1,T2,T3], axis=1, join='inner')
pd.merge(T1,T2, how='left', on=['id','name'])
pd.melt(df2, id_vars= ['Year', 'Model'], var_name='Price', value_name='$')
pd.melt.pivot_table(index=['Year', 'Model'], columns='Price', values='$'])

import matplotlib.pyplot as plt
import numpy as np

df2.set_index(['Year','Price'], inplace=True)
df2.plot(title='Data')
plt.show()

fig, ax = plt.subplots(figsize=(8,5))
df2.plot(y="Speed", use_index=True,color='red')
ax.set_title('Speed Data')
ax.set_xlabel('Km/h')
plt.show()

fig = plt.figure()
fig = plt.figure(figsize=(14,14))

ax1=plt.subplot(221)
ax1=plt.subplot(222)
plt.show()

df2.plot.scatter(x='Motor',y='Speed', c= ['g' if s==0 else 'r' for s in df2.Speed.values])
plt.show()

pd.plotting.scatter_matrix(df2)
plt.show()

df2[['Wheel','Speed']].plot.hist(alpha=0.8,bins=15,title="Wheel & Speed")
plt.show()

df2.Wheel.value_counts().plot.bar(title='Wheels')
plt.show()

df2.Wheel.value_counts().plot.barh(title='Wheels-H')
plt.show()

plt.bar(x,y)
plt.show()

df2[['Wheel','Speed']].plot.box(title="Wheel & Speed")
plt.grid()
plt.show()

df2.Wheel.value_counts().plot.pie(title='Wheels')
plt.show()

import requests
from bs4 import BeautifulSoup as BSp

URL = "http://lhr.nu"
r = requests.get(URL)
soup =BSp(r.content,'html.parser')
data = soup.find('div', id = 'fsc').find_All('div', class_='card')

import cv2

img = cv2.imread('anato/m/1.png', 0) # 1 for color images default
%matplotlib inline
plt.imshow(img)

%matplotlib notebook
plt.imshow(img, cmap='gray')

RGB_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(RGB_img)

RGB_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
plt.imshow(RGB_img, cmap='gray')

plt.imshow(img[:,::-1], cmap='gray') #reverse img

plt.imshow(img[50:100,200:300])


